#ifndef MAINWINDOW_HH
#define MAINWINDOW_HH

#include <QMainWindow>
#include <QGraphicsRectItem>
#include <QGraphicsScene>
#include <QTimer>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();


private slots:


    void createDiscs(int discs);
    void createPoles();
    void onPlayButtonclicked();
    void adjustSceneArea(int width, int height);



    void on_restartButton_clicked();

private:
    Ui::MainWindow *ui;

    QGraphicsScene scene_;
    QGraphicsRectItem* poleA_ = nullptr;
    QGraphicsRectItem* poleB_ = nullptr;
    QGraphicsRectItem* poleC_ = nullptr;
    QGraphicsRectItem* table_ = nullptr;
    QGraphicsRectItem* disc_ = nullptr;

    const int width_ =  45;
    const int height_ = 11;
    const int poleHeight = 9;
    int discs_;


};

#endif // MAINWINDOW_HH

