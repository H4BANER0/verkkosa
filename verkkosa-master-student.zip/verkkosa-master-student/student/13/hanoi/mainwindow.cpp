#include "mainwindow.hh"
#include "ui_mainwindow.h"
#include <QGraphicsRectItem>
#include <QApplication>


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    ui->graphicsView->setScene(&scene_);
    ui->spinBox->setMinimum(3);
    ui->spinBox->setMaximum(8);
    ui->restartButton->setEnabled(false);

    QColor color(Qt::white);
    color.setAlphaF(0.3);
    ui->graphicsView->setBackgroundBrush(QBrush(color, Qt::SolidPattern));

    connect(ui->playButton, SIGNAL(clicked()),
            this, SLOT(onPlayButtonclicked()));
}



MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::createPoles()
{
    const QRectF poleA(7, 1, 1, poleHeight);
    const QRectF poleB(22, 1, 1, poleHeight);
    const QRectF poleC(37, 1, 1, poleHeight);
    const QRectF table(0, height_-1, width_, 1);
    const QPen penPole(Qt::black, 0.02);
    const QBrush brushPole(Qt::darkBlue);
    poleA_ = scene_.addRect(poleA, penPole, brushPole);
    poleB_ = scene_.addRect(poleB, penPole, brushPole);
    poleC_ = scene_.addRect(poleC, penPole, brushPole);
    table_ = scene_.addRect(table, penPole, brushPole);
}

void MainWindow::adjustSceneArea(int width, int height)
{
    const QRectF area(0, 0, width, height);
    scene_.setSceneRect(area);
    ui->graphicsView->fitInView(area);
}

void MainWindow::createDiscs(int discs)
{
    const QPen penDisc(Qt::black, 0.02);
    for(int i = discs;i > 0;i--){
        const QRectF disc(8-i, 10-i,2*i-1, 1);
        const QBrush brushDisc(Qt::white);
        QColor color(200, i * 20, 100);
        disc_ = scene_.addRect(disc, penDisc, brushDisc);
        disc_->setBrush(color);

    }


}
void MainWindow::onPlayButtonclicked()
{

    adjustSceneArea(width_, height_);
    createPoles();
    discs_ = ui->spinBox->value();
    createDiscs(discs_);
    ui->playButton->setEnabled(false);
    ui->spinBox->setEnabled(false);
    ui->restartButton->setEnabled(true);

}


void MainWindow::on_restartButton_clicked()
{
    ui->playButton->setEnabled(true);
    ui->spinBox->setEnabled(true);
    ui->restartButton->setEnabled(false);
}
