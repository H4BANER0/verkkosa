




/*
 * Program author
 * Name: Harri Verkkosaari
 * Student number: 275319
 * UserID: verkkosa ( Necessary due to gitlab folder naming. )
 * E-Mail: harri.verkkosaari@tuni.fi
 */
#include <iostream>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <algorithm>

using namespace std;

// The most magnificent function in this whole program.
// Prints a RASSE
void print_rasse()
{
    std::cout <<
                 "=====//==================//===\n"
                 "  __<<__________________<<__   \n"
                 " | ____ ____ ____ ____ ____ |  \n"
                 " | |  | |  | |  | |  | |  | |  \n"
                 " |_|__|_|__|_|__|_|__|_|__|_|  \n"
                 ".|                  RASSE   |. \n"
                 ":|__________________________|: \n"
                 "___(o)(o)___(o)(o)___(o)(o)____\n"
                 "-------------------------------" << std::endl;
}
// japaa syötetyn vector stringiksi ja palauttaa ne mainiin
vector<string> split(const string& s,
                     const char delimiter,
                     bool ignore_empty = false) {

    vector<string> result;
    string tmp = s;

    while(tmp.find(delimiter) != string::npos)
    {
        string new_part = tmp.substr(0, tmp.find(delimiter));
        tmp = tmp.substr(tmp.find(delimiter)+1, tmp.size());
        if(not (ignore_empty and new_part.empty()))
        {
            result.push_back(new_part);
        }
    }
    if(not (ignore_empty and tmp.empty()))
    {
        result.push_back(tmp);
    }
    return result;
}
// käy kaikki databasenavaimet läpi ja tulostaa niiden tiedot
void print(const string& nimi, map<string, vector<string>>& database, string sisennys){


    for (unsigned int i = 0; i < database[nimi].size(); i++){

        print(database[nimi][i], database, sisennys);

        cout << sisennys << database[nimi][i] << endl;
    }


}
// tarkistaa löytyyko databasen avaimen mukaisesta listasta pysäkki
int loytyyko(const string& nimi, map<string, vector<string>>& database,
            string pysakki){

    if (find(database.at(nimi).begin(), database.at(nimi).end(), pysakki)
            != database.at(nimi).end()) {
        return 1;
    }
    if (find(database.at(nimi).begin(), database.at(nimi).end(), pysakki)
            == database.at(nimi).end()) {
        return 0;
    }
    return 0;
}
// tallennetaan listaan pysäkit
void tallennus(const string& nimi,
               map<string, vector<string>>& database, vector<string>& lista){

    for (unsigned int i = 0; i < database[nimi].size(); i++) {
        // jos listalla on jo pysäkki, sitä ei lisätä uudestaan listalle
        if (find(lista.begin(), lista.end(), database[nimi].at(i)) != lista.end()) {
            continue;
        } else {
            lista.push_back(database[nimi][i]);
        }

    }



}
// remove etsii nimen ja database mapin avulla halutun pysäkin.
void remove(const string& nimi,
            map<string, vector<string>>& database,
            string pysakki,
            vector<string>& lista) {

    vector<string>::iterator it = find(lista.begin(), lista.end(), pysakki);
    // etsii indexin missä pysäkki on mapin second arvoista eli listasta
    int index = distance(database.at(nimi).begin(),
                         (find(database.at(nimi).begin(),
                               database.at(nimi).end(), pysakki)));
    // saadaan indeksi listasta poistoa varten
    int indexlist = distance(lista.begin(), it);
    // tarkistaa onko pysäkki mapissa halutun nimen vectorissa, jos on se
    // poistetaan mapista ja listasta jossa on kaikki pysäkit
    if (find(database.at(nimi).begin(), database.at(nimi).end(), pysakki)
            != database.at(nimi).end()) {

        database.at(nimi).erase(database.at(nimi).begin()+index);
        lista.erase(lista.begin()+indexlist);
    }
    // jos linja lyötyy jostain syystä pysäkkien joukosta
    if (find(lista.begin(),lista.end(), nimi) != lista.end()){
        database.erase(nimi);
    }



}
// muuttaa kaikki kirjaimet pieniksi jotta saataisiin komennot samanlaisiksi
// eikä isot ja pienet kirjaimet haittaa
void lower_string(string& str)
{
    for(int i=0;str[i]!='\0';i++)
    {
        if (str[i] >= 'A' && str[i] <= 'Z')    //checking for uppercase characters
            str[i] = str[i] + 32;         //converting uppercase to lowercase
    }

}



// Short and long main.
int main()
{
    // database on map jota tässä koodissa käytän
    map<string, vector<string>> database;
    // listaan tallennetaan jokaisen while loopin alussa pysäkit
    vector<string> lista;
    print_rasse();
    cout << "Give a name for input file: ";
    string input_tiedosto = "";
    getline(cin, input_tiedosto);
    ifstream infile;
    infile.open(input_tiedosto);
    // tarkistaa voiko tiedoston avata
    if ( not infile ) {
        cout << "Error: File could not be read." << endl;
        return EXIT_FAILURE;

    } else {
        for (string line; getline(infile, line); ) {
            // tarkastaa onko tiedostossa kaikki arvot luettavia
            // jos ei napataan errori
            try {
                vector<string> parts = split(line, ';', true);
                string linja = parts.at(0);
                string nimi = parts.at(1);
                database[linja].push_back(nimi);
            } catch (exception &i ){
                cout << "Error: Invalid format in file." << endl;
                return EXIT_FAILURE;
            }
        }
    }

    bool ohjelma = true;
    // muutama tarvittava iteraattori eri käyttötarkoituksiin
    map<string, vector<string>>::iterator iter;
    vector<string>::iterator iter1;
    // ohjelma jatkuu kunnes siitä poistutaan
    while (ohjelma)
    {

        cout << "tramway> ";
        string command = "";
        getline(cin, command);
        // ekan välin avulla voidaan rajata komento
        int ekavali = command.find(" ");        
        string comma = command.substr(0,ekavali);
        // muutetaan komento pieniksi kirjaimiksi
        lower_string(comma);
        // tallennetaan databasen avaimen mukaan listaan kaikki pysäkit
        for (iter = database.begin(); iter != database.end(); iter++) {
            tallennus(iter->first, database, lista);
        }
        // tulostaa kaikki linjat eli databasen avaimet
        if (comma == "lines") {
            cout << "All tramlines in alphabetical order:" << endl;
            for (iter = database.begin(); iter != database.end(); iter++) {
                // tarkistetaan ettei pysäkkejä ole joutunut linjojen sekaan
                // jos on se poistetaan
                if (find(lista.begin(),lista.end(),iter->first) != lista.end()){                    
                    continue;
                } else {
                    // tulostetaan avaimet
                    cout << iter->first << endl;
                }
            }
        }
        // comma.size() < command.size() estää tyhjän syötteen komennon jälkeen
        // komento lisää linjan databaseen
        else if (comma == "addline" and comma.size() < command.size()) {
            vector<string> osat = split(command, ' ', true);
            string linja = osat.at(1);
            // jos avaimissa ei ole linjaa, se lisätään databaseen
            // jos linja on jo avainten joukossa tulostetaan virhe
            if (database.find(linja) == database.end()) {
                vector<string> tyhja;                
                database[linja] = tyhja;
                cout << "Line was added." << endl;
            } else {
                cout << "Error: Station/line already exists." << endl;

            }
        }
        // komento lisää databasen avaimeen arvon
        else if (comma == "addstation" and comma.size() < command.size()) {
            try {
                // tiedot osaan kuuluu kaikki muu syötteestä paitsi comma
                // jos virhe ilmenee tulee errori
                string tiedot = command.substr(ekavali, command.size());
                // tiedot splitataan 2-3 osaan riippuen sanojen määrästä
                vector<string> osat = split(tiedot, ' ', true);
                string linja = osat.at(0);
                string pysakki = osat.at(1);
                string toinen_pysakki;
                int osien_koko = osat.size();

                // jos pysäkki ei ole databasen avaimen arvoissa
                if (find(database[linja].begin(),
                         database[linja].end(),
                         pysakki)== database[linja].end()) {

                    // jos osia on 2 niin ne lisätään avaimen eli linjan
                    // mukaiseen kohtaan
                    if (osien_koko == 2) {
                        database[linja].push_back(pysakki);
                        cout << "Station was added." << endl;
                    }
                    // jos osia on 3 niin katsotaan onko 3. sana
                    // eli 2. pysäkki databasessa jos on niin mennään
                    // suoritetaan tämä if toiminto
                    else if (osien_koko == 3 and
                             find(database[linja].begin(),
                                  database[linja].end(),
                                  osat.at(2)) != database[linja].end()) {

                        toinen_pysakki = osat.at(2);
                        // toisen pysäkin index antaa arvon monentenako
                        // toinen_pysäkki on mapin syövereissä
                        int toisen_pysakin_index =
                                distance(database.at(linja).begin(),
                                             (find(database.at(linja).begin(),
                                                   database.at(linja).end(),
                                                   toinen_pysakki)));
                        // lisätään pysäkki vektoriin
                        // haluttuun kohtaan ennen toista pysäkkiä
                        database[linja].insert(
                                    database[linja].begin()+
                                    toisen_pysakin_index,pysakki);

                        cout << "Station was added." << endl;
                    }
                    // jos osia on 3 niin katsotaan onko 3. sana
                    // eli 2. pysäkki databasessa jos ei niin mennään
                    // suoritetaan tämä if toiminto
                    // tällöin pysäkki lisätään vektoriin ilman mietteitä
                    else if (osien_koko == 3 and
                             find(database[linja].begin(),
                                  database[linja].end(),
                                  osat.at(2)) == database[linja].end()) {

                        database[linja].push_back(pysakki);
                        cout << "Station was added." << endl;
                    }

                }
                // jos ei mitään muuta niin tulostetaan virhe
                else {
                    cout << "Error: Station/line already exists." << endl;
                }


            }
            // nappaa virheen ja ilmoittaa siitä tekstillä
            catch (exception &i ) {
                cout << "Error: Invalid input." << endl;
                continue;
            }
        }


        // printtaa kaikki pysäkit aakkojärjestyksessä
        else if (comma== "stations") {
            cout << "All stations in alphabetical order:" << endl;

            sort(lista.begin(), lista.end());
            for (unsigned int i = 0; i < lista.size(); i++) {
                cout << lista.at(i) << endl;
            }
        }
        // printtaa pyydetyn pysäkin kaikki linjat jotka siinä kulkevat
        else if (comma == "station" and comma.size() < command.size()) {
            // jos syötteessä on " merkki niin toimitaan tämän if:in mukaisesti
            if (command.find('"') != string::npos) {
                vector<string> osat = split(command, '"', true);
                string comma = osat.at(0);
                string pysakki = osat.at(1);
                // jos löytyneitä linjoja pysäkille on 0 niin printataan virhe
                int loytyneita = 0;
                for (iter = database.begin(); iter != database.end(); iter++) {
                    if (loytyyko(iter->first, database, pysakki) == 1){
                        loytyneita += 1;
                        }
                }
                // jos pysäkkiä ei löydy databasesta
                if (loytyneita == 0) {
                    cout << "Error: Station could not be found." << endl;

                }
                // taas jos yksikin löytyy niin ne tulostetaan joissa pysäkki on
                else if (loytyneita != 0) {
                    cout << "Station " << pysakki
                         << " can be found on the following lines:"
                         << endl;
                    for (iter = database.begin(); iter != database.end(); iter++) {
                        if (loytyyko(iter->first, database, pysakki) == 1){
                            cout << "- " << iter->first << endl;
                            }
                        }
                }

            }
            // jos taas ei ole " merkkiä niin toimitaan tämän elsen mukaan
            // muuten toiminnot on samat. split toiminto on vain kustomoitu
            else {
                int index = distance(command.begin(), command.end());
                string pysakki = command.substr(8,index-8);
                // jos löytyneitä linjoja pysäkille on 0 niin printataan virhe
                // jos pysäkki löytyy databasesta niin paluu arvo on 1
                // jos ei niin 0. Jos for loopin jälkeen edelleen 0 niin
                // tulostuu virhe ilmoitus
                int loytyneita = 0;
                for (iter = database.begin(); iter != database.end(); iter++) {
                    if (loytyyko(iter->first, database, pysakki) == 1){
                        loytyneita += 1;
                        }
                }
                // jos pysäkkiä ei löydy databasesta
                if (loytyneita == 0) {
                    cout << "Error: Station could not be found." << endl;

                }
                // taas jos yksikin löytyy niin ne tulostetaan joissa pysäkki on
                else if (loytyneita != 0) {
                    cout << "Station " << pysakki
                         << " can be found on the following lines:"
                         << endl;
                    for (iter = database.begin(); iter != database.end(); iter++) {                       
                        if (loytyyko(iter->first, database, pysakki) == 1){
                            cout << "- " << iter->first << endl;
                            }
                        }
                    }
                }
            }
        // line komennolla printataan kaikki linjan pysäkit lisätyssä
        // järjestyksessä
        else if (comma == "line" and comma.size() < command.size()) {

            vector<string> osat = split(command, ' ', true);
            // komento osa on otettu tällätavoin
            string comma = command.substr(0,ekavali);

            string linja = osat.at(1);
            // estää komennon jälkeen tyhjän syötteen
            if (command.size() == comma.size()) {
                cout << "Error: Invalid input." << endl;
            }
            // tarkistetaan löytyykö databasesta haluttu linja
            // jos ei niin annetaan virhe
            else if (database.find(linja) == database.end()) {
                cout << "Error: Line could not be found." << endl;

            }
            // jos löytyy printataan kaikki linjan pysäkit
            else {
            cout << "Line " << linja
                 << " goes through these stations in the order they are listed:"
                 << endl;
            print(linja, database, "- ");
            }

        }
        // poistetaan pysäkki kokonaan listoista
        else if (comma == "remove" and comma.size() < command.size()) {
            // " merkin kanssa olevat syötteet
            if (command.find('"') != string::npos) {
                vector<string> osat = split(command, '"', true);
                string comma = osat.at(0);               
                string pysakki = osat.at(1);
                // sama toiminto kuin station komennossa. katso kommentit
                int loytyneita = 0;
                for (iter = database.begin(); iter != database.end(); iter++) {
                    if (loytyyko(iter->first, database, pysakki) == 1){
                        loytyneita += 1;
                        }
                }
                if (loytyneita == 0) {
                    cout << "Error: Station could not be found." << endl;

                }
                else if (loytyneita != 0) {
                    // tallennetaan ja poistetaan sitten halutut pois
                    for (iter = database.begin(); iter != database.end(); iter++) {
                        tallennus(iter->first, database, lista);
                        remove(iter->first, database, pysakki, lista);
                    }
                    cout << "Station was removed from all lines." << endl;
                }

            }
            // sama toiminta mutta ilman " merkkiä
            else {
                int index = distance(command.begin(), command.end());
                string pysakki = command.substr(7,index-7);

                int loytyneita = 0;
                for (iter = database.begin(); iter != database.end(); iter++) {
                    if (loytyyko(iter->first, database, pysakki) == 1){
                        loytyneita += 1;
                        }
                }
                if (loytyneita == 0) {
                    cout << "Error: Station could not be found." << endl;

                } else if (loytyneita != 0) {
                    for (iter = database.begin(); iter != database.end(); iter++) {
                        tallennus(iter->first, database, lista);
                        remove(iter->first, database, pysakki, lista);
                    }
                    cout << "Station was removed from all lines." << endl;
                }
            }
        }
        // poistutaan QUIT komennolla
        else if (command == "QUIT" or command == "quit") {
            ohjelma = false;
        }
        // virhesyötteet virhe ilmoituksella
        else {
            cout << "Error: Invalid input." << endl;
        }
    }
    return EXIT_SUCCESS;
}
