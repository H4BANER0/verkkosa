/*  Source file for NumberTile class.
 *
 * Also contains an operator for pair addition.
 *
 * Method implementations should be added to the same level as the existing
 * ones.
 * */
#include "numbertile.hh"
#include <iomanip>
#include <iostream>
#include <string>
using namespace std;
// Pair addition operator. Allows to do result_pair = pair_1 + pair_2
pair<int, int>operator +(pair<int, int> lhs, pair<int, int> rhs){
    return make_pair(lhs.first + rhs.first, lhs.second + rhs.second);
}

// Modify the second line if you don't wish to use pairs.
NumberTile::NumberTile(int value)

    : value_(value)

{



}

// Students should not touch this method.
void NumberTile::print(int width){
    // std::setw() sets the width of next printable to given amount, usually
    // by adding spaces in front.
    cout << "|" << setw(width - 1) << value_;
}
// palauttaa palikan numeroarvon
int NumberTile::getValue() const{
    return value_;
}

// muuttaa palikan arvon halutuksi.
void NumberTile::asetaArvo(int value){
    value_ = value;
}

bool NumberTile::setValue(int value){

    // jos int arvo on 0, se korvataan uudella arvolla NEW_VALUE
    if ( value_ != 0 ){
        return false;
    }
    value_ = value;
    return true;
}





