/* Numbers ( or 2048, but that's an invalid name ) : Template code
 *
 * Desc:
 *  This program generates a game of 2048, a tile combining game
 * where the goal is to get from 2's to 2048. The board is SIZE x SIZE,
 * ( original was 4x4 ) and every round the player chooses a direction
 * to which the tiles should fall. If they collide with a wall or a different
 * value, they will move as close as they can get. If they collide with
 * a tile with same value, they will combine and double the value. The
 * tile will continue to move until a wall or other tile comes along, but a
 * single tile can only be combined once per "turn".
 *  Game will end when the goal value asked (orig 2048) is reached or new
 * tile can't be added to the board.
 *
 * Program author ( Fill with your own info )
 * Name: Harri Verkkosaari
 * Student number: 275319
 * UserID: verkkosa ( Necessary due to gitlab folder naming. )
 * E-Mail: harri.verkkosaari@tuni.fi
 *
 * Notes about the program and it's implementation:
 * */

#include "numbertile.hh"
#include <iostream>
#include <vector>
#include <random>
#include <string>
using namespace std;

const int SIZE = 4;
const int NEW_VALUE = 2;
const int PRINT_WIDTH = 5;
const int DEFAULT_GOAL = 2048;

// En ymmärtänyt opiskella tätä projektia varten parien käyttöä,
// joten vaikka minua koitettiin kooditoriossa valaista sen helppoudesta
// niin päätin silti tehdä vähän mekaanisemmin tämän projektin .at() toimintoa käyttäen
// navigoidakseni boardilla eli pelilaudalla.


// Adds a single new value to board using rEng and distr for random positioning.
void newValue(vector<vector<NumberTile>> &board,
               default_random_engine &rEng,
               uniform_int_distribution<int> &distr){
    // Tries to assign NEW_VAl to randomly selected tile. Continues trying until
    // newVal() returns true.
    while(!board.at(distr(rEng)).at(distr(rEng)).setValue(NEW_VALUE));
}

// Initializes the board to size SIZE x SIZE and adds SIZE tiles with NEW_VALUE
// to it through new_value() func after initializing the random engine with
// a seed value.
void initBoard(vector<vector<NumberTile>> &board,
                default_random_engine &rEng,
                uniform_int_distribution<int> &distr){

    // Initialize the board with SIZE x SIZE empty numbertiles.
    for ( auto y = 0; y < SIZE; y++ ){
        board.push_back({});
        for ( auto x = 0; x < SIZE; x++ ){
            // If you don't want to use pairs, replace "std::make_pair(y, x)"
            // with "y, x".
            board.at(y).push_back(NumberTile(0));
        }

    }

    // Ask user for the seed value and initialize rEng.
    cout << "Give a seed value or an empty line: ";
    string seed = "";
    getline(cin, seed);

    if(seed == "") {
        // If the user did not give a seed value, use computer time as the seed
        // value.
        rEng.seed(time(NULL));
    } else {
        // If the user gave a seed value, use it.
        rEng.seed(stoi(seed));
    }

    // Add some tiles to the board.
    for ( int i = 0 ; i < SIZE ; ++i ){
        newValue(board, rEng, distr);
    }
}

// Funktion tehtävä on liikutella palikoita. EI yhdistää.
// tarkistetaan tyhjät paikat että voiko haluttuun suuntaan siirtää
// tyhjään paikkaan siirretään liikuteltava arvo ja liikuteltavan arvon paikalle tulee tyhjä eli 0
void movetiles(vector<vector<NumberTile>> &board, string &direction){

     // Siirtää palikat oikealle
    if ( direction == "w" ){
        for ( int x = 0; x < 4; ++x ){
            for ( int y = 1; y < 4; ++y ){
                if ( board.at(y - 1).at(x).getValue() == 0){
                    board.at(y - 1).at(x).asetaArvo(board.at(y).at(x).getValue());
                    board.at(y).at(x).asetaArvo(0);
                }
            }
        }
    }
    // Siirtää palikat vasemmalle
    else if ( direction == "a" ){
        for ( int x = 1; x <= 3; ++x ){
            for ( int y = 0; y < 4; ++y ){
                if ( board.at(y).at(x - 1).getValue() == 0){
                    board.at(y).at(x - 1).asetaArvo(board.at(y).at(x).getValue());
                    board.at(y).at(x).asetaArvo(0);
                }
            }
        }
    }
     // Siirtää palikat alas
    else if ( direction == "s" ){
        for ( int x = 0; x < 4; ++x ){
            for ( int y = 2; y >= 0; --y ){
                if ( board.at(y + 1).at(x).getValue() == 0){
                    board.at(y + 1).at(x).asetaArvo(board.at(y).at(x).getValue());
                    board.at(y).at(x).asetaArvo(0);
                }
            }
        }
    }
     // Siirtää palikat ylös
    else if ( direction == "d" ){
        for ( int x = 2; x >= 0; --x ){
            for ( int y = 0; y < 4; ++y ){
                if ( board.at(y).at(x + 1).getValue() == 0){
                    board.at(y).at(x + 1).asetaArvo(board.at(y).at(x).getValue());
                    board.at(y).at(x).asetaArvo(0);
                }
            }
        }
    }
}

// Funktion tehtävä on etsiä ja yhdistää vierekkäisiä saman arvoisia palikoita
// mihin suuntaan niitä vedetäänkään.
// sisempänä oleva palikka saa arvon 0 ja ulomman yhdistyneen arvoksi tulee alkuperäinen luku * 2
void addtiles(vector<vector<NumberTile>> &board, string &direction){

    // yhdistää ylöspäin liikkuvat numerot
    if ( direction == "w" ){
        for ( int x = 0; x < 4; ++x ){
            for ( int y = 0; y <= 2; ++y ){
                if ( board.at(y + 1).at(x).getValue() == board.at(y).at(x).getValue()){
                    board.at(y).at(x).asetaArvo(board.at(y + 1).at(x).getValue() * 2);
                    board.at(y + 1).at(x).asetaArvo(0);
                }
            }
        }
    }

    // yhdistää vasemmalle liikkuvat numerot
    else if ( direction == "a" ){
        for ( int x = 0; x <= 2; ++x ){
            for ( int y = 0; y < 4; ++y ){
                if ( board.at(y).at(x + 1).getValue() == board.at(y).at(x).getValue()){
                    board.at(y).at(x).asetaArvo(board.at(y).at(x + 1).getValue() * 2);
                    board.at(y).at(x + 1).asetaArvo(0);
                }
            }
        }
    }

    // yhdistää alas liikkuvat numerot
    else if ( direction == "s" ){
        for ( int x = 0; x < 4; ++x ){
            for ( int y = 2; y >= 0; --y ){
                if ( board.at(y + 1).at(x).getValue() == board.at(y).at(x).getValue()){
                    board.at(y + 1).at(x).asetaArvo(board.at(y).at(x).getValue() * 2);
                    board.at(y).at(x).asetaArvo(0);
                }
            }
        }
    }

    // yhdistää oikealle liikkuvat numerot
    else if ( direction == "d" ){
        for ( int x = 2; x >= 0; --x ){
            for ( int y = 0; y < 4; ++y ){
                if ( board.at(y).at(x + 1).getValue() == board.at(y).at(x).getValue()){
                    board.at(y).at(x + 1).asetaArvo(board.at(y).at(x).getValue() * 2);
                    board.at(y).at(x).asetaArvo(0);
                }
            }
        }
    }
}

// Funktio määrää milloin numeroita liikutellaan. 1. ja 2. kerralla for looppia
// palat liikkuvat määrättyyn suuntaan = direction.
// 3. kerralla eli kun i = 2 addTiles funktioyhdistää
// vierekkäin tai päällekäin olevat numerot jos ovat samoja
void makeMove(vector<vector<NumberTile>> &board, string &direction){
    for ( int i = 0; i <= 3; ++i){
        if (i == 2){
            addtiles(board, direction);
        }
        else{
            movetiles(board, direction);
        }
    }
}

// Prints the board.
void print(vector<vector<NumberTile>> &board){
    // The y isn't actually the y coordinate or some int, but an iterator that
    // is like a vector of NumberTiles.
    for ( auto y : board ){
        // Prints a row of dashes.
        cout << string(PRINT_WIDTH * SIZE + 1, '-') << endl;
        // And then print all cells in the desired width.
        for ( auto x : y ){
            x.print(PRINT_WIDTH);
        }
        // And a line after each row.
        cout << "|" << endl;
    }
    // Print a last row of dashes so that the board looks complete.
    cout << string(PRINT_WIDTH * SIZE + 1, '-') << endl;
}

// Tarkistaa onko peli voitettu eli päästy valittuun goal arvoon. palauttaa truen jos on päästy.
// jos peliä ei vielä voitettu palautetaan false.
bool gameWon( vector<vector<NumberTile>> board, int goal, bool &tosi){
    for ( int x = 0; x < 4; ++x ){
        for ( int y = 0; y < 4; ++y ){
            if ( board.at(y).at(x).getValue() == goal){

                // lopettaa pelin kun tosi saa false arvon.
                if ( tosi ){
                    print(board);
                    cout << "You reached the goal value of " << goal << "!" << endl;
                    tosi = false;
                }
                return true;
            }
        }
    }
    return false;
}

// Tarkistaa hävisiköpelaaja pelin.
bool gameLost(vector<vector<NumberTile>> &board, bool &tosi){

       // etsii tyhjät palikat ruudukosta
       for ( int x = 0; x < 4; ++x ){
           for ( int y = 0; y < 4; ++y ){
               if ( board.at(y).at(x).getValue() == 0 ){
                   return false;
               }
           }
       }

       // samoja arvoja vierekkäisiä tai päällekkäisiä arvoja etsivä toiminto
       // eli voiko jotain palikkaa vielä liikuttaa.
       for ( int x = 0; x < 3; ++x ){
           for ( int y = 0; y < 3; ++y ){
               if ( board.at(y).at(x).getValue() == board.at(y).at(x + 1).getValue() or
                    board.at(y).at(x).getValue() == board.at(y + 1).at(x).getValue()){
                   return false;
               }
           }
       }for ( int x = 3; x > 0; --x ){
           for ( int y = 3; y > 0; --y ){
               if ( board.at(y).at(x).getValue() == board.at(y).at(x - 1).getValue() or
                    board.at(y).at(x).getValue() == board.at(y - 1).at(x).getValue()){
                   return false;
               }
           }
       }

       // tosi saa false arvon kun peli päättyy.
       if ( tosi ){
           print(board);
           cout << "Can't add new tile, you lost!" << endl;
           tosi = false;
       }
       return true;
}

int main()
{
    // Declare the board and randomengine.
    vector<vector<NumberTile>> board;
    default_random_engine randomEng;
    // And initialize the disrt to give numbers from the correct
    uniform_int_distribution<int> distr(0, SIZE - 1);
    initBoard(board, randomEng, distr);


    // Kysyy kuinka paljon yhden palikan luvun pitää olla että peli loppuu voittoon
    cout << "Give a goal value or an empty line: ";
    string goalstr = "";
    getline(cin, goalstr);
    int goal = DEFAULT_GOAL;

    // estää väärät syötteet kuten kirjaimet ja sanat.
    // toimii saman tyyppisesti PYTHON toiminnon try-expect tavoin.
    try {
        goal = stoi(goalstr);
    } catch (const invalid_argument &i ){}

    // bool muuttuja gameWon ja gameLost funktioihin
    // muuttuja takaa että tulostus tapahtuu vain kerran, kun pelaaja häviää tai voittaa.
    bool tosi = true;

    // while loop pyörittää peliä kunnes se saa toden arvon gameWon tai gameLost funktioista
    while ( !gameWon(board, goal, tosi) and !gameLost(board, tosi) ){

        print(board);
        cout << "Dir> ";
        // estää tyhjän syötteen
        string dir = "";
        getline(cin, dir);

        // sulkee kaikki muut kirjaimet kuin halutut pois vaihtoehdoista.
        if ( dir != "a" and dir != "w" and dir != "s" and dir != "d" and dir != "q" ){
            cout << "Error: unknown command." << endl;
        }
        else if ( dir == "q" ) {
            return 0;
        }
        else {
            //siirtyy funktioon, jokaliikuttaa palasia halutun direction = dir mukaisesti
            makeMove(board, dir);
        }
        // arpoo uuden arvon 2 vain jos peli on vielä käynnissä
        if ( !gameWon(board, goal, tosi) and !gameLost(board, tosi)){
            newValue(board, randomEng, distr);
        }



    }
}
