#include <iostream>
#include <string>
#include <vector>
#include <cstring>

using namespace std;
// TODO: Implement split function here
// Do not change main function
vector<string> split(string str, char sep = ' ', bool skip_empty = false){
    vector<string> splitted = {};
    while (str.find(sep) != string::npos) {
        string cut = str.substr(0, str.find(sep));
        if ( cut.size() != 0){
            splitted.push_back(cut);
        }
        if (cut.size() == 0 and skip_empty == false){
            splitted.push_back("");
        }
        str = str.substr(str.find(sep) + 1);
    }
    if ( str.size() != 0){
        splitted.push_back(str);
    }
    else if ( str.size() == 0 and skip_empty == false){
        splitted.push_back("");
    }
    return splitted;
}

int main()
{
    std::string line = "";
    std::cout << "Enter a string: ";
    getline(std::cin, line);
    std::cout << "Enter the separator character: ";
    char separator = getchar();

    std::vector< std::string > parts  = split(line, separator);
    std::cout << "Splitted string including empty parts: " << std::endl;
    for( auto part : parts ) {
        std::cout << part << std::endl;
    }

    std::vector< std::string > parts_no_empty  = split(line, separator, true);
    std::cout << "Splitted string ignoring empty parts: " << std::endl;
    for( auto part : parts_no_empty ) {
        std::cout << part << std::endl;
    }
}
