#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;



int main()
{
    cout << "Input file: ";
    string input_tiedosto = "";
    getline(cin, input_tiedosto);

    cout << "Output file: ";
    string output_tiedosto = "";
    getline(cin, output_tiedosto);

    ifstream infile;
    ofstream outfile;
    infile.open(input_tiedosto);
    if ( not infile ) {
        cout << "Error! The file " << input_tiedosto << " cannot be opened." << endl;
        return EXIT_FAILURE;

    } else {

        outfile.open(output_tiedosto);

        int numero = 1;
        vector<string> lines;
        for (string line; getline(infile, line); ) {
           lines.push_back(line);
        }
        int rivit = lines.size();
        for( int i = 0; i < rivit; ++i ){

            outfile << numero<< " " << lines.at(i) << endl;


            numero++;

        }
    }
    infile.close();
    outfile.close();
    return 0;
}
