#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <cctype>
#include <algorithm>

using namespace std;

int main()
{
    cout << "Input file: ";
    string input_tiedosto = "";
    getline(cin, input_tiedosto);

    ifstream infile(input_tiedosto);
    if ( not infile ){
        cout << "Error! The file " << input_tiedosto << " cannot be opened." << endl;
        return EXIT_FAILURE;
    } else {



    }
}
