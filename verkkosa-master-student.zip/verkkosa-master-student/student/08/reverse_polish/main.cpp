#include <iostream>
#include <fstream>
#include <vector>
#include <ctype.h>
#include <algorithm>

using namespace std;
vector<string> split(const string& s,
                     const char delimiter,
                     bool ignore_empty = false) {

    vector<string> result;
    string tmp = s;

    while(tmp.find(delimiter) != string::npos)
    {
        string new_part = tmp.substr(0, tmp.find(delimiter));
        tmp = tmp.substr(tmp.find(delimiter)+1, tmp.size());
        if(not (ignore_empty and new_part.empty()))
        {
            result.push_back(new_part);
        }
    }
    if(not (ignore_empty and tmp.empty()))
    {
        result.push_back(tmp);
    }
    return result;
}

int calculations(vector<int> numbers, vector<string> operators) {
    bool divisionByZero = false;
    int result = 0;

    for (auto o: operators) {
        if (o == "+") {
            result = numbers.at(0) + numbers.at(1);
        } else if (o == "-") {
            result = numbers.at(0) - numbers.at(1);
        } else if (o == "*") {
            result = numbers.at(0) * numbers.at(1);
        } else if (o == "/") {
            if (numbers.at(1) == 0) {
                cout << "Error: Division by zero" << endl;
                divisionByZero = true;
            }

            result = numbers.at(0) / numbers.at(1);
        }

        numbers.erase(numbers.begin());
        numbers.at(0) = result;
    }
    if (!divisionByZero) {
        return result;
    }

    return EXIT_FAILURE;
}

int main() {
    cout << "Input an expression in reverse Polish notation (end with #):"
         << endl;

    string expression;
    cout << "EXPR> ";
    getline(cin, expression);

    // Split parts of the user input.
    vector<string> parts = split(expression, ' ', true);
    if (parts.back() == "#") {
        parts.pop_back();
    }

    vector<string> operators;
    vector<int> numbers;
    int partsSize = parts.size();

    for (int i = 0; i < partsSize; i++) {
        if (parts.back() == "+" || parts.back() == "-" ||
                parts.back() == "*" || parts.back() == "/") {
            operators.push_back(parts.back());
            parts.pop_back();
        } else {
            try {
                stoi(parts.front());
            } catch (...) {
                cout << "Error: Expression must start with a number" << endl;
                return EXIT_FAILURE;
            }

            try {
                int n = stoi(parts.back());
                numbers.push_back(n);
                parts.pop_back();
            } catch (...) {
                cout << "Error: Unknown character" << endl;
                return EXIT_FAILURE;
            }
        }
    }

    int numbersSize = numbers.size();
    int operatorsSize = operators.size();

    if (numbersSize > operatorsSize+1) {
        cout << "Error: Too few operators" << endl;
        return EXIT_FAILURE;
    } else if (numbersSize < operatorsSize+1) {
        cout << "Error: Too few operands" << endl;
        return EXIT_FAILURE;
    }

    reverse(numbers.begin(), numbers.end());

    int result = calculations(numbers, operators);
    cout << "Correct: " << result << " is the result"
         << endl;
}
