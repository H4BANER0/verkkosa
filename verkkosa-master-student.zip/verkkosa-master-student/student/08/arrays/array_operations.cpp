#include "array_operations.hh"
#include <iostream>
#include <algorithm>
using namespace std;
int greatest_v1(int* itemptr, int size){

    int largest = 0;
    for(int* position = itemptr; position < itemptr + size; ++position) {
        if(*position < largest) {
            continue;
        }
        else {
            largest = *position;
        }
    }
    return largest;

}
int greatest_v2(int* itemptr, int* endptr) {
    int largest = 0;
    for(int* position = itemptr; position < endptr; ++position) {
        if(*position < largest) {
            continue;
        }
        else {
            largest = *position;
        }
    }
    return largest;
}
void copy(int* itemptr, int* endptr, int* targetptr) {

    for(int* position = itemptr; position < endptr; ++position) {
        *targetptr = *position;
        ++targetptr;
       }

}
void reverse(int* leftptr, int* rightptr) {
    // pointer1 pointing at the beginning of the array
        int* pointer1 = leftptr;

            // pointer2 pointing at end of the array
        int* pointer2 = rightptr - 1;
        while (*pointer1 < *pointer2) {
            swap(*pointer1, *pointer2);
            pointer1++;
            pointer2--;
        }

}
