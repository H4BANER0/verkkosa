/* Module: Loan
 * ------------
 * This class and its bahaviour should be defined by the student.
 *
 * TIE-0220x S2019
 * */
#ifndef LOAN_HH
#define LOAN_HH

#include "book.hh"
#include "loan.hh"
#include "date.hh"
#include <string>

const int DEFAULT_RENEWAL_AMOUNT = 6;
class Loan
{
public:
    Loan(std::string loaner,
         std::string book_name,
         Date* duedate);
    // Tuhoaja metodi
    ~Loan();
    // palauttaa lainaajan nimen
    std::string get_loaner() const;
    // palauttaa kirjan nimen
    std::string get_book_name() const;
    // palauttaa kirjan palautus päivän
    Date get_due_date();
    // Tarkastaa onko palautus päivä pienempi kuin nykyhetki
    // jos on palautetaan true kirja on myöhässä
    bool is_late(Date *today);
    // Muuttaa palautus päivämäärän
    void change_duedate(Date date);
    // Tulostus metodi lainojen tietoja varten
    // borrower saa valmiiksi arvoksi tyhjän jos lainaajan eli borrowerin
    // lainoja ei kohdennetusti haluta tietää
    void print_info(Date* today, std::string borrower="");

private:
    std::string loaner_;
    std::string book_name_;
    Date* due_date_;
    int renewals_;
};
#endif
