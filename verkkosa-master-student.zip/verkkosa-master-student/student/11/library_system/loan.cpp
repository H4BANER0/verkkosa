#include "loan.hh"
#include "date.hh"

#include <iostream>
using namespace std;
Loan::Loan(std::string loaner,
           std::string book_name,
           Date* duedate):
    loaner_(loaner), book_name_(book_name), due_date_(duedate), renewals_(0)
{
}

string Loan::get_loaner() const
{
    return loaner_;
}

string Loan::get_book_name() const
{
    return book_name_;
}

Date Loan::get_due_date(){
    return* due_date_;
}

bool Loan::is_late(Date *today) {
    return due_date_->operator < (*today);
}

void Loan::change_duedate(Date date){
    // tarkastetaan onko vielä lainaus kertoja jäljellä
    // jos kerrat ovat loppu ilmoitetaan se errorilla
    if (renewals_ < DEFAULT_RENEWAL_AMOUNT){
        date.advance_by_loan_length();

        unsigned int day = date.getDay();
        unsigned int month = date.getMonth();
        unsigned int year = date.getYear();
        // poistetaan vanha due_date_ ja tehdään uusi
        delete due_date_;
        Date* due = new Date{day,month,year};
        due_date_ = due;
        // uudelleen lainauksen arvoa kasvatetaan
        renewals_++;
        // printataan uusi päivämäärä
        cout << "Renewal was successful. New due date: "
                  << due->getDay() << "."
                  << due->getMonth() << "."
                  << due->getYear() << endl;
    } else {
        cout << "Error: Loan is out of renewals." << endl;
    }
}
// Tulostaa lainatuista kirjoista infon joko yleisesti tai
// vain lainaajaan kohdentuvat tiedot
void Loan::print_info(Date* today, string borrower) {
    if(borrower == ""){
        cout << book_name_ << " : " <<
                loaner_ << " : " <<
                due_date_->getDay() << "." <<
                due_date_->getMonth() << "."  <<
                due_date_->getYear() << " : ";
        // tarkistetaan onko laina myöhässä 1=myöhässä, 0=ei
        if ( is_late(today) ) {
            cout << "1" << endl;
        }
        else {
            cout << "0" << endl;
        }
    }
    // Tulostaa vain lainaajan lainaustiedot
    else if ( loaner_ == borrower ) {
        cout << book_name_ << " : " <<
                due_date_->getDay() << "." <<
                due_date_->getMonth() << "."  <<
                due_date_->getYear() << " : ";
        // tarkistetaan onko laina myöhässä 1=myöhässä, 0=ei
        if ( is_late(today) ) {
            cout << "1" << endl;
        }
        else {
            cout << "0" << endl;
        }
    }
}
// Tuhoaja
Loan::~Loan(){
    delete due_date_;
    due_date_ = nullptr;
}

