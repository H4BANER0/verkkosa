#include "library.hh"
#include <iostream>
using namespace std;
// Let's use the date when the project was published as the first date.
Library::Library():
    today_(new Date(13, 11, 2019)),
    books_({}),
    authors_({}),
    accounts_({}),
    loans_({})
{

}

Library::~Library()
{
    // Free all memory reserved with the keyword new.
    delete today_; today_ = nullptr;
    for ( std::pair<std::string, Book*> book : books_ ){
        delete book.second;
        book.second = nullptr;
    }
    for ( std::pair<std::string, Person*> author : authors_ ){
        delete author.second;
        author.second = nullptr;
    }
    for ( std::pair<std::string, Person*> account : accounts_ ){
        delete account.second;
        account.second = nullptr;
    }
}

void Library::all_books()
{
    for ( std::pair<std::string, Book*> book : books_ ){
        std::cout << book.first << std::endl;
    }
}

void Library::all_books_with_info()
{
    std::cout << SEPARATOR_LINE << std::endl;
    for ( std::pair<std::string, Book*> book : books_ ){
        book.second->print_info();
        std::cout << SEPARATOR_LINE << std::endl;
    }
}

void Library::all_borrowers()
{
    for ( std::pair<std::string, Person*> borrower : accounts_ ){
        std::cout << borrower.first << std::endl;
    }
}

void Library::all_borrowers_with_info()
{
    std::cout << SEPARATOR_LINE << std::endl;
    for ( std::pair<std::string, Person*> borrower : accounts_ ){
        borrower.second->print_info();
        std::cout << SEPARATOR_LINE << std::endl;
    }
}

bool Library::add_book(const std::string &title, const std::vector<std::string> authors, const std::string &description, const std::set<std::string> genres)
{
    if ( authors.empty() ){
        std::cout << MISSING_AUTHOR_ERROR << std::endl;
        return false;
    }
    std::vector<Person*> author_ptrs;
    for ( std::string author : authors ){
        Person* n_person;
        if ( authors_.find(author) == authors_.end() ){
            n_person = new Person(author, "", "");
            authors_.insert({author, n_person});
        } else {
            n_person = authors_.at(author);
        }
        author_ptrs.push_back(n_person);
    }
    Book* n_book = new Book(title, author_ptrs, description, genres);
    books_.insert({title, n_book});
    return true;
}

void Library::add_borrower(const std::string &name, const std::string &email,
                           const std::string &address)
{
    if ( accounts_.find(name) != accounts_.end()){
        std::cout << DUPLICATE_PERSON_ERROR << std::endl;
        return;
    }

    Person* n_person = new Person(name, email, address);
    accounts_.insert({name, n_person});
}

void Library::set_date(int day, int month, int year)
{
    delete today_;
    today_ = new Date(day, month, year);
    today_->show();
}

void Library::advance_date(int days)
{
    today_->advance_by(days);
    today_->show();
}
// Listaa kaikki olemassa olevat lainat
void Library::loaned_books()
{
    // käydään vektorin alkiot läpi ja tulostetaan infot
    // jos vektori ei ole tyhjä. Muutoin mitään ei tulostu
    if(loans_.size() != 0) {
        cout << LOAN_INFO << endl;
        for(auto loan : loans_){
            loan->print_info(today_);
        }
    }
}
// Listaa lainaajan kaikki lainat
void Library::loans_by(const std::string &borrower)
{
    // Metodi on hyvin samankaltainen kuin loaned_books
    // lainaajan lisääminen on kuitenkin erona näiden välillä.
    if(!person_found(borrower)) {
        cout << CANT_FIND_ACCOUNT_ERROR<<endl;
    }
    else if(loans_.size() != 0) {
        for(auto loan : loans_){
            loan->print_info(today_, borrower);
        }
    }
}
// Lainaus metodi
void Library::loan(const std::string &book_title,
                   const std::string &borrower_id)
{
    // jos kirja on valikoimassa voidaan jatkaa, muutoin error.
    if(book_found(book_title))
    {
        // jos lainaaja on valikoimassa, voidaan jatkaa, muutoin error
        if(person_found(borrower_id)){
            // jos laina ei vielä ole sellainen luodaan,
            // muutoin error. Estää siis duplikaatit
            if(!loan_found(book_title)){
                unsigned int day = today_->getDay();
                unsigned int month = today_->getMonth();
                unsigned int year = today_->getYear();
                Date* due = new Date{day,month,year};

                due->advance_by_loan_length();
                loans_.push_back(new Loan(borrower_id, book_title, due));
            }
            else{
                cout << ALREADY_LOANED_ERROR << endl;
            }
        }
        else{
            cout << CANT_FIND_ACCOUNT_ERROR << endl;
        }
    }
    else {
        cout << CANT_FIND_BOOK_ERROR << endl;
    }
}
// tarkistus metodi olemassa olevan lainan etsimiselle
bool Library::loan_found(std::string book_title)
{
    // käydään läpi alkioita. jos nimi löytyy, palautetaan true muutoin false
    for (auto loan : loans_){
        if(loan->get_book_name() == book_title){
            return true;
        }
    }
    return false;
}
// tarkistus metodi lainaajan löytymiselle
bool Library::person_found(std::string name)
{
    // käydään läpi alkioita. jos nimi löytyy palautetaan true muutoin false
    for (auto account : accounts_){
        if(account.first == name){
            return true;
        }
    }
    return false;
}
// tarkistus metodi kirjan löytymiselle
bool Library::book_found(std::string book)
{
    // käydään läpi alkioita. jos nimi löytyy palautetaan true muutoin false
    for (auto i : books_){
        if(i.first == book){
            return true;
        }
    }
    return false;
}
// Metodi uudelleen lainausta varten
void Library::renew_loan(const std::string &book_title)
{   // kirjan löytyessä siirrytään muuttamaan duedate Loan.cpp tiedostoon
    // jos kirjaa ei input tiedostosta lainoista tai
    // book_title ei löydy lainoista
    if(book_found(book_title)) {
        bool hits = false;
        for(auto loan : loans_) {
            if(loan->get_book_name() == book_title) {
                loan->change_duedate(loan->get_due_date());
                hits = true;
            }
        }
        if(hits != true) {
            cout << LOAN_NOT_FOUND_ERROR << endl;
        }
    }
    else {
        cout << CANT_FIND_BOOK_ERROR << endl;
    }

}
// Lainan palautus metodi
void Library::return_loan(const std::string& book_title) {
    bool loanfound = loan_found(book_title);
    bool bookfound = book_found(book_title);
    int n = 0; if(loanfound && bookfound) {
        // Käydään läpi lainattujen kirjojen listaa ja jos löytyy book_titlea
        // vastaava kirja, se poistetaan ja tuhotaan Loan::~Loan() metodissa
        for(Loan* i : loans_) {
            if(i->get_book_name() == book_title) {
                loans_.erase(loans_.begin()+n);
                i->~Loan();
                cout<< RETURN_SUCCESSFUL << endl;
            }
            n++;
        }
    }
    // jos palautettavaa tai kirjaa ei löydy tulee error
    else if (!bookfound) {
        cout << CANT_FIND_BOOK_ERROR << endl;
    }
    else {
        cout << LOAN_NOT_FOUND_ERROR << endl;
    }
}
