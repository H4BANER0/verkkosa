#include "cards.hh"
#include <iostream>
#include <cstdlib>


// TODO: Implement the methods here
using namespace std;
Cards::Cards(): top_(nullptr) {
}
Cards::~Cards() {

   while ( top_ != nullptr ) {
      Card_data* data_to_be_released = top_;
      top_ = top_->next;

      delete data_to_be_released;
   }

}
void Cards::add(int id) {
    Card_data* item = new Card_data{id,top_};
    if(top_!=nullptr){
        top_=top_->next;
    }
    top_=item;
}
void Cards::print_from_top_to_bottom(std::ostream& s){
    Card_data* data_to_be_released = top_;
    int running_number = 1;

    while ( data_to_be_released != nullptr ) {
       s << running_number << ". " << data_to_be_released->data << endl;
       ++running_number;
       data_to_be_released = data_to_be_released->next;
    }
}
bool Cards::remove(int& id) {

    if(top_==nullptr){
        return false;
    }
    else {

        Card_data* data_to_be_released = top_;
        id = data_to_be_released->data;
        delete data_to_be_released;
        top_=top_->next;
        return true;
    }
}
bool Cards::bottom_to_top() {
    if (top_ == nullptr) {
            return false;
        } else if (top_->next == nullptr) {  // If there is only one card left, do nothing.
            return true;
        }

        Card_data* second_last_ptr = top_;

        while (second_last_ptr->next->next != nullptr) {
            second_last_ptr = second_last_ptr->next;
        }

        Card_data* old_last_ptr = second_last_ptr->next;

        second_last_ptr->next = nullptr;
        old_last_ptr->next = top_;
        top_ = old_last_ptr;

        return true;


}
bool Cards::top_to_bottom() {

    if (top_ == nullptr) {
           return false;
       } else if (top_->next == nullptr) {  // If there is only one card left, do nothing.
           return true;
       }

       Card_data* first_ptr = top_;
       Card_data* last_ptr = top_;

       while (last_ptr->next != nullptr) {
           last_ptr = last_ptr->next;
       }

       top_ = first_ptr->next;
       first_ptr->next = nullptr;
       last_ptr->next = first_ptr;

       return true;

}
void Cards::print_from_bottom_to_top(std::ostream& s) {
    Card_data* data_to_be_released = top_;
    int running_number = 1;

    while ( data_to_be_released != nullptr ) {
       s << running_number << ". " << data_to_be_released->data << endl;
       ++running_number;
       data_to_be_released = data_to_be_released->next;
    }
}

