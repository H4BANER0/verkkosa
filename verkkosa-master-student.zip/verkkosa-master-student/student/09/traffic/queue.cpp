#include "queue.hh"
#include <iostream>


// Implement the member functions of Queue here
using namespace std;

Queue::Queue(unsigned int cycle) {
    cycle_ = cycle;
}
Queue::~Queue() {

}
void Queue::enqueue(string reg) {
    Vehicle* new_car = new Vehicle{reg, nullptr};

    if (first_ == nullptr) {
        first_ = new_car;
        last_ = new_car;
        if (is_green_ == true) {
            cout << "GREEN: The vehicle " << first_->reg_num << " need not stop to wait" << endl;
            dequeue();
        }
    } else {
        last_->next = new_car;
        last_ = new_car;
    }
}
void Queue::print(ostream& s) {
    string light = "";
    if (is_green_) {
        light = "GREEN";
    } else {
        light = "RED";
    }

    Vehicle* current_ptr = first_;
    if (current_ptr == nullptr) {
        s << light << ": No vehicles waiting in traffic lights" << endl;

    } else {
        s << light << ": Vehicle(s) ";
        while (current_ptr != nullptr) {
            s << current_ptr->reg_num << ' ';
            current_ptr = current_ptr->next;
        }
        s << "waiting in traffic lights" << endl;
    }



}
void Queue::switch_light() {

    string valo = "";
    if(is_green_ == false){
        is_green_ = true;
        valo = "GREEN";
    } else {
        is_green_ = false;
        valo = "RED";
    }
    Vehicle* current_ptr = first_;
    if (current_ptr == nullptr) {
        cout << valo << ": No vehicles waiting in traffic lights" << endl;

    } else {

        cout << valo << ": Vehicle(s) ";
        for (unsigned int i = 0; i < cycle_; i++) {
            if (current_ptr != nullptr) {
                cout << current_ptr->reg_num << ' ';
                current_ptr = current_ptr->next;
                if (is_green_ == true )
                    dequeue();
            }
        }
        if (is_green_ == true) {
            cout << "can go on" << endl;
                is_green_ = false;
        } else {
            is_green_ = false;
            cout << "waiting in traffic lights" << endl;
        }
    }

}
void Queue::reset_cycle(unsigned int cycle) {
    cycle_ = cycle;
}
void Queue::dequeue() {
    Vehicle* removable_ptr = first_;
    first_ = first_->next;
    delete removable_ptr;
}
