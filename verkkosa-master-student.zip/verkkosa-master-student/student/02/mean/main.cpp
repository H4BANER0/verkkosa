#include <iostream>

using namespace std;

// Write here a function counting the mean value

int main()
{
    int lukuja;
    cout << "From how many integer numbers you want to count the mean value? ";
    cin >> lukuja;
    if ( lukuja == 0) {
        cout << "Cannot count mean value from 0 numbers" << endl;
        return 0;
    }

    float summa = 0;
    for ( int luku = 1; luku <= lukuja; ++luku ) {
        int arvo;
        cout << "Input " << luku << ". " << "number: ";
        cin >> arvo;
        summa += arvo;
    }
    cout << "Mean value of the given numbers is " << summa / lukuja << endl;
    return 0;
}
