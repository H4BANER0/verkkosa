#include <iostream>

using namespace std;

int main()
{
    int lampo;
    cout << "Enter a temperature: ";
    cin >> lampo;
    float fahr;
    fahr = (lampo * 1.8) + 32;
    cout << lampo << " degrees Celsius is " << fahr << " degrees Fahrenheit" << endl;
    float cels = (lampo - 32) / 1.8;
    cout << lampo << " degrees Fahrenheit is " << cels << " degrees Celsius" << endl;

    // Write your code here

    return 0;
}
