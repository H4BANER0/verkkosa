#include <iostream>

using namespace std;

int main()
{
    int numero;
    cout << "Enter a number: ";
    cin >> numero;
    if ( numero * numero * numero < 0 ) {
        cout << "The cube of " << numero << " is not " << (numero * numero * numero) << "." << endl;
        return 0;
    }
    else if ( numero >= 0 ) {
        cout << "The cube of " << numero << " is " << (numero * numero * numero) << "." << endl;
        return 0;
    }

    return 0;
}
