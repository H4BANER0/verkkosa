#include <iostream>

using namespace std;

int main()
{
    bool b = 1 + 2;
    cout << b << endl;

    if ( 1 + 2 ) {
        cout << "Hip" << endl;
    }



    return 0;
}
