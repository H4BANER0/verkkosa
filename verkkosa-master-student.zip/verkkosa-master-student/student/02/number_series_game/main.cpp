#include <iostream>

using namespace std;

int main()
{
    int numero;
    cout << "How many numbers would you like to have? ";
    cin >> numero;
    for ( int luku = 1; luku <= numero; ++luku ) {
        if ( luku % 3 == 0 and luku % 7 == 0 ) {
            cout << "zip boing" << endl;
        }
        else if ( luku % 7 == 0 ) {
            cout << "boing" << endl;
        }
        else if ( luku % 3 == 0) {
            cout << "zip" << endl;
        }
        else {
            cout << luku << endl;
        }
    }
    return 0;
}
