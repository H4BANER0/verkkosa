/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.6
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout;
    QSlider *horizontalSliderRed;
    QLabel *labelBlue;
    QLabel *labelRed;
    QSlider *horizontalSliderBlue;
    QSlider *horizontalSliderGreen;
    QLabel *labelGreen;
    QLabel *colorLabel;
    QSpinBox *spinBoxBlue;
    QSpinBox *spinBoxGreen;
    QSpinBox *spinBoxRed;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(400, 300);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        gridLayoutWidget = new QWidget(centralWidget);
        gridLayoutWidget->setObjectName(QStringLiteral("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(50, 80, 181, 101));
        gridLayout = new QGridLayout(gridLayoutWidget);
        gridLayout->setSpacing(6);
        gridLayout->setContentsMargins(11, 11, 11, 11);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        horizontalSliderRed = new QSlider(gridLayoutWidget);
        horizontalSliderRed->setObjectName(QStringLiteral("horizontalSliderRed"));
        horizontalSliderRed->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(horizontalSliderRed, 1, 1, 1, 1);

        labelBlue = new QLabel(gridLayoutWidget);
        labelBlue->setObjectName(QStringLiteral("labelBlue"));

        gridLayout->addWidget(labelBlue, 3, 0, 1, 1);

        labelRed = new QLabel(gridLayoutWidget);
        labelRed->setObjectName(QStringLiteral("labelRed"));

        gridLayout->addWidget(labelRed, 1, 0, 1, 1);

        horizontalSliderBlue = new QSlider(gridLayoutWidget);
        horizontalSliderBlue->setObjectName(QStringLiteral("horizontalSliderBlue"));
        horizontalSliderBlue->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(horizontalSliderBlue, 3, 1, 1, 1);

        horizontalSliderGreen = new QSlider(gridLayoutWidget);
        horizontalSliderGreen->setObjectName(QStringLiteral("horizontalSliderGreen"));
        horizontalSliderGreen->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(horizontalSliderGreen, 2, 1, 1, 1);

        labelGreen = new QLabel(gridLayoutWidget);
        labelGreen->setObjectName(QStringLiteral("labelGreen"));

        gridLayout->addWidget(labelGreen, 2, 0, 1, 1);

        colorLabel = new QLabel(centralWidget);
        colorLabel->setObjectName(QStringLiteral("colorLabel"));
        colorLabel->setGeometry(QRect(300, 100, 62, 51));
        spinBoxBlue = new QSpinBox(centralWidget);
        spinBoxBlue->setObjectName(QStringLiteral("spinBoxBlue"));
        spinBoxBlue->setGeometry(QRect(240, 150, 49, 29));
        spinBoxGreen = new QSpinBox(centralWidget);
        spinBoxGreen->setObjectName(QStringLiteral("spinBoxGreen"));
        spinBoxGreen->setGeometry(QRect(240, 110, 49, 29));
        spinBoxRed = new QSpinBox(centralWidget);
        spinBoxRed->setObjectName(QStringLiteral("spinBoxRed"));
        spinBoxRed->setGeometry(QRect(240, 80, 49, 29));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 400, 25));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        labelBlue->setText(QApplication::translate("MainWindow", "blue:", Q_NULLPTR));
        labelRed->setText(QApplication::translate("MainWindow", "red:", Q_NULLPTR));
        labelGreen->setText(QApplication::translate("MainWindow", "green:", Q_NULLPTR));
        colorLabel->setText(QApplication::translate("MainWindow", "TextLabel", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
