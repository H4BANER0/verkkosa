#include "mainwindow.hh"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QPalette* palette1 = new QPalette();
    palette1->setColor(QPalette::Background, Qt::darkGreen);
    ui->lcdNumberMin->setAutoFillBackground(true);
    ui->lcdNumberMin->setPalette(*palette1);

    QPalette* palette2 = new QPalette();
    palette2->setColor(QPalette::Background, Qt::darkCyan);
    ui->lcdNumberSec->setAutoFillBackground(true);
    ui->lcdNumberSec->setPalette(*palette2);

    timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &MainWindow::stopwatch);

    connect(ui->closeButton, SIGNAL(clicked()), this, SLOT(close()));
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_startButton_clicked()
{
    timer->start(1000);
}

void MainWindow::on_stopButton_clicked()
{
    timer->stop();
}

void MainWindow::on_resetButton_clicked()
{
    timer->stop();
    minute = 0;
    second = 0;

}

void MainWindow::stopwatch()
{
    ui->lcdNumberMin->display(minute);
    ui->lcdNumberSec->display(second);
    if (second != 59) {
        second += 1;
    } else {
        second = 0;
        minute += 1;
    }
}
