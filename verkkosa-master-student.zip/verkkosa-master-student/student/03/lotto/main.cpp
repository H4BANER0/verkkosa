#include <iostream>

using namespace std;

int lotto(int numeroita, int nostettu){
    unsigned long int osoittaja = 1;
    unsigned long int nimittaja = 1;
    unsigned long int vastaus;
    unsigned long int nimittaja1 = 1;


    int suluissa = numeroita - nostettu;
    for ( int luku = nostettu; luku > 0; --luku ){
            osoittaja *= numeroita;
            numeroita -= 1;
            nimittaja *= suluissa ;
            suluissa -= 1;
            nimittaja1 *= luku;
    }
    vastaus = (osoittaja / nimittaja1);
    return vastaus;

}
int main()
{
    int numeroita;
    int nostettu;

    cout << "Enter the total number of lottery balls: ";
    cin >> numeroita;
    cout << "Enter the number of drawn balls: ";
    cin >> nostettu;
    if ( numeroita <= 0 or nostettu <= 0){
        cout << "The number of balls must be a positive number." << endl;
        return 0;
        }
    if ( numeroita < nostettu ) {
        cout << "The maximum number of drawn balls is the total amount of balls." << endl;
        return 0;
    }
    if ( lotto(numeroita, nostettu) == 0 ){
        return 0;
    }
    cout << "The probability of guessing all " << nostettu << " balls correctly is " << "1/" << lotto(numeroita, nostettu) << endl;
    return 0;
}
