#include "player.hh"
#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

Player::Player(string vuoro):
    vuoro_(vuoro) {
}
string Player::get_name() const{
    return vuoro_;
}

int Player::get_points() {
    return pisteet_;
}
bool Player::has_won() {
    if ( pisteet_ == 50 ) {
        return true;
    }
    else {
       return false;
    }
}
void Player::add_points(int pts) {
    pisteet_ += pts;
    if ( pisteet_ > 50 ){
        cout << vuoro_ << " gets penalty points!" << endl;
        pisteet_ = 25;
    }

}
