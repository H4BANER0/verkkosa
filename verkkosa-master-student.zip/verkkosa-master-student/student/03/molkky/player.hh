#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;

class Player {
public:
    Player(string vuoro);
    string get_name() const;
    int get_points();
    bool has_won();
    void add_points(int pts);
private:
    string vuoro_;
    int pisteet_ = 0;
};


