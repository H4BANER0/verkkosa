#include "swap.hh"

// TODO: Implement swap function here
void swap(int& i, int& j)
{
    int luku = i;
    int luku1  = j;
    j = luku;
    i = luku1;
}

