#include <iostream>
#include <cctype>


using namespace std;

int tarkistus(string avain)
{
    string aakkoset = "abcdefghijklmnopqrstuvwxyz";
    string isotaakkoset = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    for ( int i = 0; i < 26; ++i) {

        if (avain.length() != 26) {
            cout << "Error! The encryption key must contain 26 characters." << endl;
            return 0;
        }

        if ( islower(avain[i]) == false ){
            cout << "Error! The encryption key must contain only lower case characters." << endl;
            return 0;
        }

        if (avain.find(aakkoset[i]) == string::npos){
            cout << "Error! The encryption key must contain all alphabets a-z." << endl;
            return 0;
            }
    }
    return true;
}

int main()
{
    string avain;
    cout << "Enter the encryption key: ";
    cin >> avain;
    if (tarkistus(avain) == 0) {
        return EXIT_FAILURE;
    }

    string encryption;
    cout << "Enter the text to be encrypted: ";
    cin >> encryption;

    string aakkoset = "abcdefghijklmnopqrstuvwxyz";
    string encrypted = "";
    for ( int i = 0; i < 26; ++i ) {
        if ( isupper(encryption[i]) == true ) {
            cout << "Error! The encryption key must contain only lower case characters." << endl;
            return 0;
        }
    }
    int pituus = encryption.size();
    for ( int i = 0; i < pituus ; ++i) {
        encrypted += avain[(aakkoset.find(encryption[i]))];
    }

    cout << "Encrypted text: " << encrypted << endl;

}
